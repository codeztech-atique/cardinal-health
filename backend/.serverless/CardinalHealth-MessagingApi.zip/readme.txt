The backend is written in Nodejs

Entry point of the application - 

node local.js